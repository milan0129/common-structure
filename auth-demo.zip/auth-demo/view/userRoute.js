const express = require('express');
const router = express.Router();
const userModel = require('../model/userModel');
const verifyToken = require('../middleware/headerValidation');

router.post('/signup', (req, res) => {
    userModel.createUser(req, res)
});

router.post('/login', (req, res) => {
    userModel.loginUser(req, res);
});

router.put('/update', verifyToken, (req, res) => {
    userModel.updateUser(req, res);
});

router.delete('/delete', verifyToken, (req, res) => {
    userModel.deleteUser(req, res);
});

router.get('/address',verifyToken, (req,res) => {
    userModel.getUserAddress(req,res)
})

module.exports = router;
