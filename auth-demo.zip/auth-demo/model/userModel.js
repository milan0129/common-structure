const connection = require('../database/conection');
const md5 = require('md5');
const common = require('../common');
let userModel = {
    createUser: async (req, res) => {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({ message: 'All fields are required' });
        }
        const query = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
        connection.query(query, [name, email, md5(password)], (error, results) => {
            if (error) {               
                return res.status(500).json({ message: 'Something went wrong!' });
            }
            res.status(201).json({ message: 'User created successfully', userId: results.insertId });
        });
    },

    loginUser: async (req, res) => {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ message: 'Email and password are required' });
        }
        const query = 'SELECT * FROM users WHERE email = ? AND password = ?';
        connection.query(query, [email, md5(password)], (error, results) => {
            if (error) {             
                return res.status(500).json({ message: 'Something went wrong!' });
            }
            if (results.length === 0) {
                return res.status(401).json({ message: 'Invalid email or password' });
            }
          
            var token = common.generate_jwt_token(results[0].id);
            res.status(200).json({ message: 'Login successful', user: results[0], token });
        });
    },

    updateUser: async (req, res) => {
        const body = req.body;
        const userId = req.user_id;
        console.log('user_id', userId, 'body', body);
        // return;



        let updateFields = [];
        let queryParams = [];
        if (body.name) {
            updateFields.push('name = ?');
            queryParams.push(body.name);
        }
        if (body.password) {
            updateFields.push('password = ?');
            queryParams.push(md5(body.password));
        }
        queryParams.push(userId);
        const query = `UPDATE users SET ${updateFields.join(', ')} WHERE id = ?`;
        connection.query(query, queryParams, (error, results) => {
            if (error) {
                return res.status(500).json({ message: 'Something went wrong!' });
            }
            if (results.affectedRows === 0) {
                return res.status(404).json({ message: 'User not found' });
            }
            res.status(200).json({ message: 'User updated successfully' });
        });
    },

    deleteUser: async (req, res) => {
        const userId = req.user_id;
        const query = 'SELECT * FROM users WHERE id = ?';
        connection.query(query, [userId], (error, results) => {
            if (error) {
                return res.status(500).json({ message: 'Something went wrong!' });
            }
            if (results.length === 0) {
                return res.status(404).json({ message: 'User not found' });
            }
            const deleteQuery = 'DELETE FROM users WHERE id = ?';
            connection.query(deleteQuery, [userId], (error, results) => {
                if (error) {
                    return res.status(500).json({ message: 'Something went wrong!' });
                }
                res.status(200).json({ message: 'User deleted successfully' });
            });
        });
    },
  

    getUserAddress: async (req,res)=>{
        const userId = req.user_id
        const query = 'SELECT us.name,us.created_at, count(ad.id)  FROM  users AS us JOIN user_address AS ad ON us.id = ad.user_id WHERE us.id = ? GROUP BY ad.user_id';
        connection.query(query, [userId], (error, results) => {
            if (error) {
                return res.status(500).json({ message: 'Something went wrong!' });
            }
            if (results.length === 0) {
                return res.status(404).json({ message: 'User address not found' });
            }
            res.status(200).json({ message: 'User address fetched successfully', data: results });
        });
    },

}

module.exports = userModel;
