require('dotenv').config();
const jwt = require('jsonwebtoken')

const common = {
    generate_jwt_token: (user_id, expiresIn = "1d") => {
        const data = {
            expiresIn,
            data: { user_id }
        }

        const token = jwt.sign(data, process.env.JWT_SECRET_KEY);
        console.log('token', token)
        return token;
    },

};

module.exports = common;
