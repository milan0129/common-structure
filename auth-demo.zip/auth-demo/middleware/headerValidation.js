require('dotenv').config();
const jwt = require('jsonwebtoken');
const verifyToken = (req, res, next) => {

    const token = req.headers['token'];
    if (!token) {
        return res.status(401).json({ message: 'Access denied. No token provided.' });

    }
    try {

        const { data } = jwt.verify(token, process.env.JWT_SECRET_KEY);
        console.log('Decoded data:', data);
      req.user_id = data.user_id;
        next(); 
    } catch (error) {
        console.error('Error verifying token:', error);
        return res.status(401).json({ message: 'Invalid token.' });
    }
};

module.exports = verifyToken;
